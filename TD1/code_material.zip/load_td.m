if exist('OCTAVE_VERSION', 'builtin') ~= 0
    pkg load statistics
end

addpath(genpath(pwd))
