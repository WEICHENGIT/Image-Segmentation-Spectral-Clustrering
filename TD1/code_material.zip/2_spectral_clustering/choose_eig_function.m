function [eig_ind] = choose_eig_function(eigenvalues)
%  [eig_ind] = choose_eig_function(eigenvalues)
%     chooses indices of eigenvalues to use in clustering
%
% Input
% eigenvalues:
%     eigenvalues sorted in ascending order
%
% Output
% eig_ind:
%     the indices of the eigenvectors chosen for the clustering
%     e.g. [1,2,3,5] selects 1st, 2nd, 3rd, and 5th smallest eigenvalues

eig_ind = ;
