function [X, Y] = get_samples(sample_dist, num_samples, dist_options)

    [X, Y] = sample_dist(num_samples,dist_options);
